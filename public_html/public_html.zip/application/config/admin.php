<?php


return [
    'login' => 'admin',
    'password' => '123',
];