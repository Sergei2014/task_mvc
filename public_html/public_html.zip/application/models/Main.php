<?php

namespace application\models;
use application\core\Model;

class Main extends Model{

    public $error;

    public function taskValidate($task){
        if(iconv_strlen($task['name']) < 3){
            $this->error = 'Имя должно быть не менне 3 символов';
            return false;
        }elseif(!filter_var($task['email'], FILTER_VALIDATE_EMAIL)){
            $this->error = 'Email введен не верно';
            return false;
        }elseif(iconv_strlen($task['text']) < 10){
            $this->error = 'Текст задачи должно быть не менне 10 символов';
            return false;
        }
        return true;
    }

    public function addTask($task){
        $params = [
            'id' => '',
            'name' => $task['name'],
            'email' => $task['email'],
            'text' => $task['text'],
            'status' => 0,
        ];
        $this->db->query('INSERT INTO task VALUES (:id, :name, :email, :text, :status)', $params);
    }


    public function taskList(){

       return $this->db->row('SELECT * FROM task ');

    }
}