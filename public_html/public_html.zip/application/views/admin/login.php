<div class="container">
    <h3>Вход</h3>
    <div class="row">
        <div class="col-md-2">
        <form id="login" action="/admin/login" method="post">
            <div class="form-group">
                <label>Логин</label>
                <input type="text" name="login" class="form-control"  placeholder="Логин">
            </div>
            <div class="form-group">
                <label>Пароль</label>
                <input type="password" name="password" class="form-control" placeholder="Пароль">
            </div>
            <button type="submit" name="enter" class="btn btn-primary">Войти</button>
        </form>
        </div>
    </div>
</div>